﻿namespace SETEC.Data.Entities
{
    public class Codgestion
    {

            public int id { get; set; }
            public string idgestion { get; set; }
            public string DescGestion { get; set; }
         
        
    }
}