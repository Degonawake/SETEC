﻿namespace SETEC.Data.Entities
{
    public class Ingresos
    {

    }
}
